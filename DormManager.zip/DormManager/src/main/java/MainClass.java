import Presentation.Controller;

/**
 * The main class of the application
 * @Author: Kovacs Paul-Adrian
 * @Since: 1.0.0
 */
public class MainClass
{
    public static void main(String[] args)
    {
        Controller theController = new Controller();
    }
}
