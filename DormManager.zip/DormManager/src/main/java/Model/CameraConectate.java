package Model;

public class CameraConectate
{
    private Integer camera1;
    private Integer camera2;

    public CameraConectate(Integer camera1, Integer camera2)
    {
        this.camera1 = camera1;
        this.camera2 = camera2;
    }

    public Integer getCamera1()
    {
        return camera1;
    }

    public void setCamera1(Integer camera1)
    {
        this.camera1 = camera1;
    }

    public Integer getCamera2()
    {
        return camera2;
    }

    public void setCamera2(Integer camera2)
    {
        this.camera2 = camera2;
    }
}
