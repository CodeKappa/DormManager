package Model;

public enum UserType
{
    SuperAdmin,
    Admin,
    Student,
    Mester,
    Bucatar,
    Invalid
}
