package Model;

public class SuperAdmini
{
    private String cnp;

    public SuperAdmini(String cnp)
    {
        this.cnp = cnp;
    }

    public String getCnp()
    {
        return cnp;
    }

    public void setCnp(String cnp)
    {
        this.cnp = cnp;
    }
}
