package Model;

public class ComplexStudentesc
{
    private String nume;

    public ComplexStudentesc(String nume)
    {
        this.nume = nume;
    }

    public String getNume()
    {
        return nume;
    }

    public void setNume(String nume)
    {
        this.nume = nume;
    }
}
