package BusinessLogic;

import DataAccess.MesterDA;

public class MesterBL
{
    private MesterDA mesterDA;

    MesterBL()
    {
        mesterDA = new MesterDA();
    }
}
