package BusinessLogic;

import DataAccess.BucatarDA;

public class BucatarBl
{
    private BucatarDA bucatarDA;

    BucatarBl()
    {
        bucatarDA = new BucatarDA();
    }
}
