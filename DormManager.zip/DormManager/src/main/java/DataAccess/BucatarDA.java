package DataAccess;

public class BucatarDA
{
}
