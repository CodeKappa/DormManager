package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.Studenti;

public class StudentDAO extends AbstractDAO<Studenti>
{
}
