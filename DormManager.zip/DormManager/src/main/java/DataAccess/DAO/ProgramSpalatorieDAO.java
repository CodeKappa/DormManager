package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.ProgramSpalatorie;

public class ProgramSpalatorieDAO extends AbstractDAO<ProgramSpalatorie>
{
}
