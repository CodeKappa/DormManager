package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.ComplexStudentesc;

public class ComplexDAO extends AbstractDAO<ComplexStudentesc>
{
}
