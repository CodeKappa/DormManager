package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.ProgramTeren;

public class ProgramareTerenDAO extends AbstractDAO<ProgramTeren>
{
}
