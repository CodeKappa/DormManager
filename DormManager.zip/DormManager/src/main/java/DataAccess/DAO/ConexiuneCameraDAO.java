package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.CameraConectate;

public class ConexiuneCameraDAO extends AbstractDAO<CameraConectate>
{
}
