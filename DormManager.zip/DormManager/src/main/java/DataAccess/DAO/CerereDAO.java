package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.CereriReparatii;

public class CerereDAO extends AbstractDAO<CereriReparatii>
{
}
