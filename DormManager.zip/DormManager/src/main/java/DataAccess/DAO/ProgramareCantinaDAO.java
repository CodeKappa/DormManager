package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.ProgramSpalatorie;

public class ProgramareCantinaDAO extends AbstractDAO<ProgramSpalatorie>
{
}
