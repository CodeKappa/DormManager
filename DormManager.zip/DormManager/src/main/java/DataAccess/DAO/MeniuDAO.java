package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.MeniuCantina;

public class MeniuDAO extends AbstractDAO<MeniuCantina>
{
}
