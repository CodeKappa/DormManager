package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.Persoane;

public class PersonaneDAO extends AbstractDAO<Persoane>
{
}
