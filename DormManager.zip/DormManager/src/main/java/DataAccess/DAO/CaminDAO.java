package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.Camin;

public class CaminDAO extends AbstractDAO<Camin>
{
}
