package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.Mesteri;

public class MesterDAO extends AbstractDAO<Mesteri>
{
}
