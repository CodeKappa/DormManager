package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.Admini;

public class AdminiDAO extends AbstractDAO<Admini>
{
}
