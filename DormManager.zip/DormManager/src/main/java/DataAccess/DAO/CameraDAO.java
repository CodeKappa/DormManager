package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.Camera;

public class CameraDAO extends AbstractDAO<Camera>
{
}
