package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.Bucatari;

public class BucatarDAO extends AbstractDAO<Bucatari>
{
}
