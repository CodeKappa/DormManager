package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.TerenDeFotbal;

public class TerenDAO extends AbstractDAO<TerenDeFotbal>
{
}
