package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.Cantina;

public class CantinaDAO extends AbstractDAO<Cantina>
{
}
