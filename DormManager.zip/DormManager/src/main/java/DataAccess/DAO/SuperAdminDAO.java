package DataAccess.DAO;

import DataAccess.AbstractDAO;
import Model.SuperAdmini;

public class SuperAdminDAO extends AbstractDAO<SuperAdmini>
{
}
