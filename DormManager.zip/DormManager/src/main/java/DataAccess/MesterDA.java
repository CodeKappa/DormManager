package DataAccess;

public class MesterDA
{
}
