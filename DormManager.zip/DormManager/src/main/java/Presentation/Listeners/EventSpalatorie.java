package Presentation.Listeners;

public interface EventSpalatorie
{
    public void selected(int zi, int ora);
    public void removeProgramare(int zi, int ora);
}
