package Presentation.GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class MesterGUI extends GUI
{
    JButton logoutButton = GUI.createButton("Log out");
    JTable usersTable = new JTable();
    Reparatii reparatii = new Reparatii(usersTable, logoutButton);


    private JTabbedPane tabbedPane;

    public MesterGUI()
    {
        this.setSize(1500, 700);
        this.setLocationRelativeTo(null);
        this.getContentPane().setLayout(new GridLayout(1, 1));
        this.getContentPane().add(makeTabbedPane());
    }

    private JTabbedPane makeTabbedPane()
    {
        Insets insets = UIManager.getInsets("TabbedPane.contentBorderInsets");
        insets.top = 0;
        insets.bottom = 0;
        insets.left = 0;
        insets.right = 0;
        UIManager.put("TabbedPane.contentBorderInsets", insets);
        UIManager.put("TabbedPane.selected", new Color(39, 39, 39));

        tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        tabbedPane.setFocusable(false);
        tabbedPane.setBackground(new Color(143, 0, 0));
        tabbedPane.setForeground(Color.WHITE);

        tabbedPane.addTab("Reparatii", null, reparatii, "Gestioneaza reparatiile");
        tabbedPane.setMnemonicAt(0, KeyEvent.VK_1);
        tabbedPane.getSelectedComponent();

        return tabbedPane;
    }

    private JComponent makeTextPanel(String text) {
        JPanel panel = new JPanel(false);
        JLabel filler = new JLabel(text);
        filler.setHorizontalAlignment(JLabel.CENTER);
        panel.setLayout(new GridLayout(1, 1));
        panel.add(filler);
        panel.setBackground(new Color(39, 39, 39));
        return panel;
    }

    public void addLogoutListener(ActionListener listener)
    {
        logoutButton.addActionListener(listener);
    }
}

class Reparatii extends JPanel
{
    JButton logoutButton;

    ArrayList<JTextField> dateUseri = new ArrayList<>();

    JTable usersTable;

    ArrayList<JLabel> labels = new ArrayList<>();
    JPanel data = new JPanel();

    JButton addButton = GUI.createButton("Marcheaza completata");
    JButton deleteButton = GUI.createButton("Marcheaza neefectuata");

    Reparatii(JTable usersTable, JButton logoutButton)
    {
        this.usersTable = usersTable;
        this.logoutButton = logoutButton;
        this.setBackground(new Color(39, 39, 39));

        data.setLayout(new GridBagLayout());
        data.setBackground(new Color(39, 39, 39));
        GridBagConstraints c = new GridBagConstraints();

        c.weighty = 1;
        c.gridy = 0; c.gridx = 0;
        c.anchor = GridBagConstraints.PAGE_START;
        c.gridwidth = 2;
        c.ipady = 1;
        c.ipadx = 1;
        JLabel labelTOP = new JLabel("Gestionare Reparatii");
        labelTOP.setForeground(Color.WHITE);
        data.add(labelTOP, c);

        c.weighty = 0;
        c.anchor = GridBagConstraints.LINE_START;
        c.gridy = 1; c.gridx = 0;
        c.gridy = 1; c.gridx = 1;
        c.anchor = GridBagConstraints.LINE_END;

        labels.add(new JLabel("ID"));      //0
        labels.add(new JLabel("Camera"));     //1
        labels.add(new JLabel("Data"));  //2
        labels.add(new JLabel("Stadiu"));   //3
        labels.add(new JLabel("Mester"));  //4

        for (JLabel label : labels)
        {
            label.setForeground(Color.WHITE);
        }

        c.gridwidth = 1;
        c.insets = new Insets(0, 0, 1, 0);
        int i;
        for (i = 0; i < labels.size(); i++)
        {
            c.gridy = i + 2; c.gridx = 0; c.anchor = GridBagConstraints.LINE_START;
            data.add(labels.get(i), c);
            c.gridy = i + 2; c.gridx = 1; c.anchor = GridBagConstraints.LINE_END;
            JTextField field = (JTextField) GUI.createField(20, false);
            field.setBackground(new Color(200, 200, 200));
            data.add(field, c);
            dateUseri.add(field);
        }

        addButton.setPreferredSize(new Dimension(275, 25));
        deleteButton.setPreferredSize(new Dimension(275, 25));
        logoutButton.setPreferredSize(new Dimension(275, 25));

        i++;
        c.insets = new Insets(10, 0, 1, 0);
        c.gridy = i + 1; c.gridx = 0;
        c.anchor = GridBagConstraints.PAGE_END;
        c.gridwidth = 2;
        data.add(addButton, c);
        c.insets = new Insets(1, 0, 1, 0);
        c.gridy = i + 3;
        data.add(deleteButton, c);
        c.gridy = i + 5;
        c.weighty = 1;
        c.anchor = GridBagConstraints.LAST_LINE_END;
        data.add(logoutButton, c);

        JScrollPane jsp = new JScrollPane(usersTable);
        jsp.getViewport().setBackground(new Color(39, 39, 39));
        jsp.getVerticalScrollBar().setBackground(new Color(143, 0, 0));
        jsp.getHorizontalScrollBar().setBackground(new Color(143, 0, 0));
        usersTable.setBackground(new Color(39, 39, 39));
        usersTable.setForeground(Color.WHITE);
        usersTable.setGridColor(new Color(143, 0, 0));
        usersTable.getTableHeader().setBackground(new Color(143, 0, 0));
        usersTable.getTableHeader().setForeground(Color.WHITE);
        usersTable.setAutoCreateRowSorter(true);
        addTableListener(new MouseAdapter()
        {
            @Override
            public void mouseClicked(MouseEvent e)
            {
                super.mouseClicked(e);
                int row = usersTable.getSelectedRow();
                for (int i = 0; i < usersTable.getColumnCount(); i++)
                {
                    String data = (String) usersTable.getValueAt(row, i);
                    dateUseri.get(i).setText(data);
                }
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);
        layout.setHorizontalGroup(
                layout.createSequentialGroup()
                        .addComponent(jsp, javax.swing.GroupLayout.DEFAULT_SIZE, 1200, Short.MAX_VALUE)
                        .addComponent(data, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(jsp, javax.swing.GroupLayout.DEFAULT_SIZE, 700, Short.MAX_VALUE)
                                .addComponent(data, javax.swing.GroupLayout.DEFAULT_SIZE, 700, Short.MAX_VALUE))
        );
    }

    public void addTableListener(MouseListener listener)
    {
        usersTable.addMouseListener(listener);
    }

    public void setTable(JTable table, ArrayList< ArrayList<String> > list)
    {
        DefaultTableModel dtm = new DefaultTableModel()
        {
            @Override
            public String getColumnName(int index)
            {
                return labels.get(index).getText();
            }

            @Override
            public boolean isCellEditable(int row, int col)
            {
                return false;
            }

            @Override
            public int getColumnCount()
            {
                return labels.size() - 1;
            }

            @Override
            public int getRowCount()
            {
                return list.size();
            }
        };

        int i = 0, j;
        for(ArrayList<String> row : list)
        {
            j = 0;
            for(String col : row)
            {
                dtm.setValueAt(col, i, j);
                j++;
            }
            i++;
        }
        table.setModel(dtm);
        repaint();
    }

    public JTable getUsersTable()
    {
        return usersTable;
    }

    public void setButtonListeners(ArrayList<ActionListener> listeners)
    {
        addButton.addActionListener(listeners.get(0));
        deleteButton.addActionListener(listeners.get(1));
    }

    public ArrayList<JTextField> getDateUseri()
    {
        return dateUseri;
    }

}
